// JavaScript Document
// Nazir Shuqair
// VFW 1308
// 29 Aug 2013
// Project 4

var json = {
	"conference1": {
		"date": ["Date: ", "2013-08-21"], 		
		"nameM": ["Name of the meeting: ", "COS Meeting"], 	
		"poc": ["Contact Number: ", "702-221-2222"],		
		"roomN": ["Room Number: ", "1-307"], 		
		"meetingT": ["Meeting Time: ", "15:13"], 	
		"checkb": ["Is a VIP Present: ", "vip"], 	
		"bridges": ["Bridge: ", "USAMTIC Audio"], 	
		"code": ["Call code: ", "32435#"], 		
		"length": ["Length of Meeting: ", "2hr"], 	
		"userR": ["Did the user respond: ", "no"], 
		"notes": ["Notes", "Nothing here"]		
	},
	"conference2": {
		"date": ["Date: ", "2014-05-25"], 		
		"nameM": ["Name of the meeting: ", "M6 Meeting"], 	
		"poc": ["Contact Number: ", "702-221-3333"],		
		"roomN": ["Room Number: ", "1-439"], 		
		"meetingT": ["Meeting Time: ", "19:43"], 	
		"checkb": ["Is a VIP Present: ", "no"], 	
		"bridges": ["Bridge: ", "TMS Video"], 	
		"code": ["Call code: ", "55555#"], 		
		"length": ["Length of Meeting: ", "1hr"], 	
		"userR": ["Did the user respond: ", "yes"], 
		"notes": ["Notes", "Something here"]		
	}
}